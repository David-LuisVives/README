package Models

abstract class Vehiculo(
    val id: Int,
    val matricula: String,
    val kilometros: Int,
    val fechaMatriculacion: String
)